from flask import Flask, render_template, request
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier

app = Flask(__name__)

# Carregando a base de dados de câncer de mama (dados fictícios)
X = np.random.rand(100, 2)
y = np.random.randint(0, 2, 100)

# Normalizando os dados
scaler = StandardScaler()
X = scaler.fit_transform(X)

# Criando o modelo KNN
knn_model = KNeighborsClassifier(n_neighbors=5)
knn_model.fit(X, y)

@app.route('/') 
def index():
    return render_template('SDIC.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        try:
            # Obtendo os parâmetros do formulário
            mean_radius = float(request.form['mean_radius'])
            mean_texture = float(request.form['mean_texture'])

            # Fazendo a previsão
            parameters = np.array([mean_radius, mean_texture])
            normalized_parameters = scaler.transform([parameters])
            prediction = knn_model.predict(normalized_parameters)
            result = 'Positivo' if prediction[0] == 1 else 'Negativo'

            return render_template('SDIC.html', result=result)

        except Exception as e:
            return render_template('SDIC.html', result=f'Erro: {str(e)}')

if __name__ == '__main__':
    app.run(debug=True)

